#!/usr/lib/python3
# Jsonx, simple j!
# By Alen(NOOB).

from pygments import lex
from pygments.lexers import Python3Lexer as JsonLexer
import json, os

class Json(object):

    jsonx = {"file":[], "data":[]}

    COLORS = {
        "red": "\033[31m",
        "white": "\033[0m",
        "blue": "\033[94m",
        "green": "\033[92m",
        "cream": "\033[91m"
    }

    def loadFromPath(self, path:str) -> None:
        # this method load's json from path.

        try:
            if os.path.exists(path):
                with open(path, "r", encoding = 'utf8') as fjson:
                    self.jsonx["file"].append([path, json.load(fjson)])
            else: raise Exception("file '{}' is not existing.".format(path))

        except Exception as err:
            raise Exception(err)

    def loadFromData(self, data:str) -> None:
        # this method load's json from data(string).

        try: self.jsonx["data"].append(self.jsonToDict(data))
        except Exception as err: raise Exception(err)

    def getLastData(self) -> str:
        # this method return's last data.
        # last-data: last loaded data from self.loadFromData.

        try: return self.jsonx["data"][-1]
        except IndexError: raise Exception("Json.getLastData(*): There isn't any data to get.")

    def getLastFile(self) -> list:
        # this method return's last file.
        # last-file: last loaded file from self.loadFromPath.

        try: return self.jsonx["file"][-1]
        except IndexError: raise KeyError("Json.getLastFile(*): There isn't any file to get.")

    def sortAll(self) -> None:
        # this method sort's self.jsonx.
        # avalibe json's will be sorted.

        self.jsonx["file"].sort(); self.jsonx["data"].sort()

    def sortDatas(self) -> None:
        self.jsonx["data"].sort()

    def sortFiles(self) -> None:
        self.jsonx["file"].sort()

    def jsonToDict(self, json:str) -> dict:
        # this method convert's json to dict.
        # this method just convert's and return's!

        return json.loads(json)

    def dictToJson(self, idict:dict) -> str:
        # this method convert's dict to json.

        return json.dumps(idict)

    def writeJsonToFile(self, index:int) -> None:
        # this method write's self.jsonx['file'][x][1] to self.jsonx['file'][x][0]

        with open(self.jsonx["file"][index][0], "w", encoding = "utf8") as jsonFile:
            json.dump(self.jsonx["file"][index][1], jsonFile)

    def setData(self, dist:str, index:int, value:str) -> None:
        # this method's set's self.jsonx data's value.

        # dist="data": this mean's that set self.jsonx["data"][x] value.
        # dist="file": this mean's that set self.jsonx["file"][x] value.

        if dist in ["data","file"]:
            if isinstance(value, str):
                if isinstance(index, int):
                    try:
                        if dist == "file": self.jsonx[dist][index][1] = value
                        else: self.jsonx[dist][index] = value
                    except Exception as err:
                        raise Exception(err)
                else:
                    TypeError("Json.setData(dist,index,value): index must be integer.")
            else:
                raise TypeError("Json.setData(dist,index,value): value must be string(json).")
        else:
            raise Exception("Json.setData(dist,index,value): dist must be file/data.")

    def getFileByIndex(self, index:int) -> list:
        # this method return's file by index.

        try: return self.jsonx["file"][index]
        except IndexError: raise Exception("Json.getFileByIndex(*): invalid index to file's list.")

    def getDataByIndex(self, index:int) -> str:
        # this method return's data by index.

        try: return self.jsonx["data"][index]
        except IndexError: raise Exception("Json.getDataByIndex(*): invalid index to data's list.")

    def getMasterJson(self, ijson:str, colors = []) -> None:
        # this is a master method!

        if isinstance(ijson, str):
            try: json.dumps(ijson)
            except Exception as err: raise Exception(f"{err}\n\tJson.getMasterJson(*): i think you did't give me json!.")
            else:
                for a, b in lex(ijson, JsonLexer()):
                    if str(a) == "Token.Literal.String.Double": yield self.colored(b,colors[0])
                    if str(a) == "Token.Text": yield b
                    if str(a) == "Token.Punctuation": yield self.colored(b,colors[1])
                    if str(a) == "Token.Literal.Number.Integer": yield self.colored(b,colors[2])
        else: raise TypeError("Json.getMasterJson(*): json must be string.")

    def colored(self, text:str, color:str) -> str:
        # this method return's colored text.

        color = self.COLORS.get(color)

        return "{}{}{}".format(color,text,color)

    def getBeautify(self, ijson:str) -> str:
        # just get beautify!

        return json.dumps(json.loads(ijson), indent = 4)

# EXM
# j = Json()
# print (j.getBeautify("{\"app\":{\"name\":\"insta\"}}"))